<?php
    if($_SESSION["type"]  != "Developer") {
        header("Location: /SOFTOWN.TECH/Login/");
        exit();
    }
    else{
        
    }

?>