<?php
    if($_SESSION["type"]  != "buyer") {
        //header("Location: /SOFTOWN.TECH/Login/");
        echo "You must be logged in with a user account";
        exit();
    }
    else{
        
    }

?>